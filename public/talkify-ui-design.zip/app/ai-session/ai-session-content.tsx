"use client"

import { useState, useEffect } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { X, Shield, Eye, Mic, Video, Trash2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { motion, AnimatePresence } from "framer-motion"
import { cn } from "@/lib/utils"

export function AISessionContent() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const prompt = searchParams?.get("prompt") || "personal-intro"
  const [isRecording, setIsRecording] = useState(false)
  const [sessionTime, setSessionTime] = useState(0)
  const [showBanModal, setShowBanModal] = useState(false)
  const [showDeleteModal, setShowDeleteModal] = useState(false)

  useEffect(() => {
    setIsRecording(true)
  }, [])

  useEffect(() => {
    if (isRecording) {
      const timer = setInterval(() => {
        setSessionTime((prev) => prev + 1)
      }, 1000)
      return () => clearInterval(timer)
    }
  }, [isRecording])

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, "0")}`
  }

  const handleForbiddenWord = () => {
    setShowBanModal(true)
    setIsRecording(false)
  }

  const handleEndSession = () => {
    router.push(`/report?prompt=${prompt}`)
  }

  const handleDeleteRecording = () => {
    setShowDeleteModal(false)
    alert("Recording deleted successfully")
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-pastel-purple/30 via-background to-pastel-pink/30 relative">
      {/* Camera View Simulation */}
      <div className="absolute inset-0 bg-gradient-to-br from-gray-900 to-gray-800">
        <div className="absolute inset-0 opacity-10">
          <div className="grid grid-cols-3 h-full">
            {[...Array(9)].map((_, i) => (
              <div key={i} className="border border-white/20" />
            ))}
          </div>
        </div>
      </div>

      {/* Header */}
      <header className="relative z-10 px-6 pt-12 pb-6 flex items-center justify-between">
        <button
          onClick={() => router.back()}
          className="w-10 h-10 rounded-full bg-black/40 backdrop-blur-sm flex items-center justify-center shadow-soft hover:scale-105 transition-transform"
        >
          <X className="w-5 h-5 text-white" />
        </button>
        <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-black/40 backdrop-blur-sm">
          <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
          <span className="text-white text-sm font-medium">{formatTime(sessionTime)}</span>
        </div>
      </header>

      {/* AI Safety Shield */}
      <div className="relative z-10 px-6">
        <motion.div
          initial={{ y: -20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className="glass rounded-3xl p-4 shadow-soft-lg flex items-center gap-3"
        >
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-success to-pastel-green flex items-center justify-center shadow-soft">
            <Shield className="w-5 h-5 text-white" />
          </div>
          <div className="flex-1">
            <h3 className="text-sm font-semibold text-foreground">AI Safety Shield Active</h3>
            <p className="text-xs text-muted-foreground">Content moderation enabled</p>
          </div>
        </motion.div>
      </div>

      {/* Center Status */}
      <div className="relative z-10 flex items-center justify-center h-[40vh]">
        <motion.div initial={{ scale: 0.8, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="text-center">
          <div className="w-24 h-24 mx-auto mb-6 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center shadow-soft-lg">
            <Mic className={cn("w-10 h-10 text-white", isRecording && "animate-pulse")} />
          </div>
          <h2 className="text-2xl font-bold text-white mb-2">Listening...</h2>
          <p className="text-white/70">Speak naturally and confidently</p>
        </motion.div>
      </div>

      {/* Bottom Controls */}
      <div className="relative z-10 px-6 pb-12 space-y-4">
        <div className="flex items-center justify-center gap-4">
          <button className="w-14 h-14 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center shadow-soft hover:scale-105 transition-transform">
            <Video className="w-6 h-6 text-white" />
          </button>
          <button
            onClick={handleEndSession}
            className="w-16 h-16 rounded-full bg-destructive flex items-center justify-center shadow-soft-lg hover:scale-105 transition-transform"
          >
            <div className="w-6 h-6 rounded bg-white" />
          </button>
          <button
            onClick={() => setShowDeleteModal(true)}
            className="w-14 h-14 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center shadow-soft hover:scale-105 transition-transform"
          >
            <Trash2 className="w-6 h-6 text-white" />
          </button>
        </div>

        <Button
          onClick={() => setShowDeleteModal(true)}
          variant="outline"
          className="w-full rounded-3xl h-12 bg-black/40 backdrop-blur-sm border-white/20 text-white hover:bg-black/60"
        >
          <Eye className="w-4 h-4 mr-2" />
          The Right to be Forgotten
        </Button>

        <Button
          onClick={handleForbiddenWord}
          variant="outline"
          className="w-full rounded-3xl h-12 bg-warning/20 backdrop-blur-sm border-warning/40 text-warning hover:bg-warning/30"
        >
          Simulate Policy Violation (Demo)
        </Button>
      </div>

      {/* Ban Modal */}
      <AnimatePresence>
        {showBanModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-6"
          >
            <motion.div
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              className="glass rounded-3xl p-8 max-w-md w-full shadow-soft-lg"
            >
              <div className="text-center space-y-4">
                <div className="w-16 h-16 mx-auto rounded-full bg-destructive/20 flex items-center justify-center">
                  <Shield className="w-8 h-8 text-destructive" />
                </div>
                <h2 className="text-2xl font-bold">User Banned</h2>
                <p className="text-muted-foreground leading-relaxed">
                  A policy violation has been detected. Your session has been terminated and your account has been
                  flagged for review.
                </p>
                <div className="pt-4 space-y-2">
                  <div className="text-sm text-muted-foreground text-left bg-muted/20 rounded-2xl p-4">
                    <p className="font-semibold mb-2">Violation Details:</p>
                    <ul className="space-y-1 text-xs">
                      <li>• Prohibited content detected</li>
                      <li>• Session timestamp: {new Date().toLocaleTimeString()}</li>
                      <li>• Review required within 24 hours</li>
                    </ul>
                  </div>
                </div>
                <Button onClick={() => router.push("/")} className="w-full rounded-3xl">
                  Return to Home
                </Button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Delete Recording Modal */}
      <AnimatePresence>
        {showDeleteModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-6"
          >
            <motion.div
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              className="glass rounded-3xl p-8 max-w-md w-full shadow-soft-lg"
            >
              <div className="text-center space-y-4">
                <div className="w-16 h-16 mx-auto rounded-full bg-warning/20 flex items-center justify-center">
                  <Trash2 className="w-8 h-8 text-warning" />
                </div>
                <h2 className="text-2xl font-bold">Delete Recording?</h2>
                <p className="text-muted-foreground leading-relaxed">
                  This will permanently delete the current recording. This action cannot be undone.
                </p>
                <div className="flex gap-3 pt-4">
                  <Button onClick={() => setShowDeleteModal(false)} variant="outline" className="flex-1 rounded-3xl">
                    Cancel
                  </Button>
                  <Button onClick={handleDeleteRecording} className="flex-1 rounded-3xl bg-destructive">
                    Delete
                  </Button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
