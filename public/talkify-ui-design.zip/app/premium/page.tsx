"use client"

import { useRouter } from "next/navigation"
import { ChevronLeft, Crown, Check, X, Sparkles, TrendingUp, Users, Headphones } from "lucide-react"
import { Button } from "@/components/ui/button"
import { motion } from "framer-motion"

const features = [
  {
    name: "Basic Reports",
    free: true,
    pro: true,
    icon: TrendingUp,
  },
  {
    name: "Advanced Visual Reports",
    free: false,
    pro: true,
    icon: Sparkles,
  },
  {
    name: "Session History (7 days)",
    free: true,
    pro: false,
  },
  {
    name: "Unlimited Mock Defenses",
    free: false,
    pro: true,
  },
  {
    name: "Group Sessions",
    free: false,
    pro: true,
    icon: Users,
  },
  {
    name: "Direct Coach Access",
    free: false,
    pro: true,
    icon: Headphones,
  },
  {
    name: "Cloud Storage (2GB)",
    free: true,
    pro: false,
  },
  {
    name: "Cloud Storage (Unlimited)",
    free: false,
    pro: true,
  },
  {
    name: "Priority Support",
    free: false,
    pro: true,
  },
]

export default function PremiumPage() {
  const router = useRouter()

  return (
    <div className="min-h-screen bg-gradient-to-br from-pastel-pink/30 via-background to-pastel-purple/30">
      {/* Header */}
      <header className="px-6 pt-12 pb-6 flex items-center gap-4">
        <button
          onClick={() => router.back()}
          className="w-10 h-10 rounded-full glass flex items-center justify-center shadow-soft hover:scale-105 transition-transform"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>
        <div className="flex-1">
          <h1 className="text-xl font-bold">Premium Membership</h1>
          <p className="text-sm text-muted-foreground">Unlock your full potential</p>
        </div>
      </header>

      {/* Main Content */}
      <main className="px-6 pb-32">
        {/* Hero Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass rounded-3xl p-8 shadow-soft-lg text-center mb-6 bg-gradient-to-br from-primary/10 to-accent/10"
        >
          <div className="w-20 h-20 mx-auto mb-4 rounded-3xl bg-gradient-to-br from-primary to-accent flex items-center justify-center shadow-soft-lg">
            <Crown className="w-10 h-10 text-white" />
          </div>
          <h2 className="text-3xl font-bold mb-2 text-balance">Go Pro Today</h2>
          <p className="text-muted-foreground leading-relaxed mb-6">
            Unlock advanced features and take your speaking skills to the next level
          </p>
          <div className="flex items-baseline justify-center gap-2">
            <span className="text-5xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
              $9.99
            </span>
            <span className="text-muted-foreground">/month</span>
          </div>
        </motion.div>

        {/* Comparison Table */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="glass rounded-3xl shadow-soft-lg overflow-hidden"
        >
          {/* Header */}
          <div className="grid grid-cols-3 gap-4 p-6 border-b border-border/50">
            <div className="text-sm font-semibold">Features</div>
            <div className="text-center">
              <div className="text-sm font-semibold">Free</div>
            </div>
            <div className="text-center">
              <div className="flex items-center justify-center gap-1.5">
                <Crown className="w-4 h-4 text-primary" />
                <span className="text-sm font-semibold text-primary">Pro</span>
              </div>
            </div>
          </div>

          {/* Features */}
          <div className="divide-y divide-border/30">
            {features.map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.2 + index * 0.05 }}
                className="grid grid-cols-3 gap-4 p-4 items-center hover:bg-muted/10 transition-colors"
              >
                <div className="text-sm">{feature.name}</div>
                <div className="flex justify-center">
                  {feature.free ? (
                    <div className="w-6 h-6 rounded-full bg-success/20 flex items-center justify-center">
                      <Check className="w-4 h-4 text-success" />
                    </div>
                  ) : (
                    <div className="w-6 h-6 rounded-full bg-muted/30 flex items-center justify-center">
                      <X className="w-4 h-4 text-muted-foreground" />
                    </div>
                  )}
                </div>
                <div className="flex justify-center">
                  {feature.pro ? (
                    <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center">
                      <Check className="w-4 h-4 text-primary" />
                    </div>
                  ) : (
                    <div className="w-6 h-6 rounded-full bg-muted/30 flex items-center justify-center">
                      <X className="w-4 h-4 text-muted-foreground" />
                    </div>
                  )}
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Pro Highlights */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="mt-6 space-y-3"
        >
          <div className="bg-pastel-green rounded-3xl p-5 shadow-soft flex items-start gap-4">
            <div className="w-10 h-10 rounded-2xl bg-success/20 flex items-center justify-center flex-shrink-0">
              <Sparkles className="w-5 h-5 text-success" />
            </div>
            <div>
              <h3 className="font-semibold text-sm mb-1">Advanced Visual Reports</h3>
              <p className="text-xs text-muted-foreground leading-relaxed">
                Get detailed timeline analysis, heatmaps, and comprehensive performance metrics
              </p>
            </div>
          </div>

          <div className="bg-pastel-blue rounded-3xl p-5 shadow-soft flex items-start gap-4">
            <div className="w-10 h-10 rounded-2xl bg-secondary/20 flex items-center justify-center flex-shrink-0">
              <Users className="w-5 h-5 text-secondary" />
            </div>
            <div>
              <h3 className="font-semibold text-sm mb-1">Group Sessions</h3>
              <p className="text-xs text-muted-foreground leading-relaxed">
                Practice with peers and get collaborative feedback in real-time
              </p>
            </div>
          </div>

          <div className="bg-pastel-purple rounded-3xl p-5 shadow-soft flex items-start gap-4">
            <div className="w-10 h-10 rounded-2xl bg-primary/20 flex items-center justify-center flex-shrink-0">
              <Headphones className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h3 className="font-semibold text-sm mb-1">Direct Coach Access</h3>
              <p className="text-xs text-muted-foreground leading-relaxed">
                Connect with professional speaking coaches for personalized guidance
              </p>
            </div>
          </div>
        </motion.div>
      </main>

      {/* Fixed Bottom CTA */}
      <div className="fixed bottom-0 left-0 right-0 p-6 glass border-t border-border/50">
        <Button className="w-full rounded-3xl h-14 bg-gradient-to-r from-primary to-accent hover:opacity-90 transition-opacity shadow-soft-lg relative overflow-hidden group">
          <motion.div
            animate={{
              backgroundPosition: ["0% 50%", "100% 50%", "0% 50%"],
            }}
            transition={{
              duration: 3,
              repeat: Number.POSITIVE_INFINITY,
              ease: "linear",
            }}
            className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent"
            style={{ backgroundSize: "200% 100%" }}
          />
          <Crown className="w-5 h-5 mr-2 relative z-10" />
          <span className="relative z-10 font-semibold">Upgrade to Pro - $9.99/mo</span>
        </Button>
      </div>
    </div>
  )
}
