"use client"

import { BottomNavigation } from "@/components/bottom-navigation"
import { Sparkles, BookOpen, Users, Trophy, MessageSquare } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useRouter } from "next/navigation"

export default function HomePage() {
  const router = useRouter()

  return (
    <div className="min-h-screen bg-gradient-to-br from-pastel-purple/30 via-background to-pastel-blue/30 pb-20">
      {/* Header */}
      <header className="px-6 pt-12 pb-6">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-12 h-12 bg-gradient-to-br from-primary to-accent rounded-3xl flex items-center justify-center shadow-soft">
            <Sparkles className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold tracking-tight">Talkify</h1>
            <p className="text-sm text-muted-foreground">Speak with confidence</p>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="px-6 space-y-6">
        {/* Welcome Card */}
        <div className="glass rounded-3xl p-6 shadow-soft-lg">
          <h2 className="text-xl font-semibold mb-2">Welcome back! 👋</h2>
          <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
            Ready to practice your speaking skills? Let's make today count.
          </p>
          <Button
            onClick={() => router.push("/profile-setup")}
            className="w-full rounded-3xl h-12 bg-gradient-to-r from-primary to-accent hover:opacity-90 transition-opacity shadow-soft"
          >
            <Sparkles className="w-4 h-4 mr-2" />
            Start Your Journey
          </Button>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-3 gap-3">
          <div className="bg-pastel-green rounded-3xl p-4 shadow-soft">
            <BookOpen className="w-5 h-5 mb-2 text-success" />
            <div className="text-2xl font-bold">12</div>
            <div className="text-xs text-muted-foreground">Sessions</div>
          </div>
          <div className="bg-pastel-blue rounded-3xl p-4 shadow-soft">
            <Trophy className="w-5 h-5 mb-2 text-secondary" />
            <div className="text-2xl font-bold">85%</div>
            <div className="text-xs text-muted-foreground">Score</div>
          </div>
          <div className="bg-pastel-pink rounded-3xl p-4 shadow-soft">
            <Users className="w-5 h-5 mb-2 text-accent" />
            <div className="text-2xl font-bold">3</div>
            <div className="text-xs text-muted-foreground">Streak</div>
          </div>
        </div>

        {/* Features Grid */}
        <div className="space-y-3">
          <h3 className="text-lg font-semibold">Practice Sessions</h3>
          <div className="space-y-3">
            <button
              onClick={() => router.push("/session-prompts")}
              className="w-full glass rounded-3xl p-5 flex items-center gap-4 shadow-soft hover:shadow-soft-lg transition-all duration-300 hover:scale-[1.02]"
            >
              <div className="w-12 h-12 bg-pastel-pink rounded-2xl flex items-center justify-center">
                <MessageSquare className="w-6 h-6 text-accent" />
              </div>
              <div className="flex-1 text-left">
                <div className="font-semibold">Personal Introduction</div>
                <div className="text-sm text-muted-foreground">Practice introducing yourself</div>
              </div>
            </button>

            <button className="w-full glass rounded-3xl p-5 flex items-center gap-4 shadow-soft hover:shadow-soft-lg transition-all duration-300 hover:scale-[1.02]">
              <div className="w-12 h-12 bg-pastel-blue rounded-2xl flex items-center justify-center">
                <BookOpen className="w-6 h-6 text-secondary" />
              </div>
              <div className="flex-1 text-left">
                <div className="font-semibold">Thesis Defense</div>
                <div className="text-sm text-muted-foreground">Prepare for academic presentation</div>
              </div>
            </button>
          </div>
        </div>
      </main>

      <BottomNavigation />
    </div>
  )
}
