"use client"

import { useRouter } from "next/navigation"
import { BottomNavigation } from "@/components/bottom-navigation"
import { Play, TrendingUp, Clock } from "lucide-react"
import { Button } from "@/components/ui/button"

const sessions = [
  {
    id: 1,
    type: "Personal Intro",
    date: "Today, 2:30 PM",
    score: 85,
    duration: "5:00",
  },
  {
    id: 2,
    type: "Thesis Defense",
    date: "Yesterday, 10:15 AM",
    score: 78,
    duration: "4:30",
  },
  {
    id: 3,
    type: "Job Interview",
    date: "Jan 9, 4:00 PM",
    score: 92,
    duration: "5:00",
  },
]

export default function SessionsPage() {
  const router = useRouter()

  return (
    <div className="min-h-screen bg-gradient-to-br from-pastel-blue/30 via-background to-pastel-purple/30 pb-20">
      {/* Header */}
      <header className="px-6 pt-12 pb-6">
        <h1 className="text-2xl font-bold mb-2">My Sessions</h1>
        <p className="text-sm text-muted-foreground">Track your progress over time</p>
      </header>

      {/* Main Content */}
      <main className="px-6 space-y-4">
        {/* New Session Button */}
        <Button
          onClick={() => router.push("/session-prompts")}
          className="w-full rounded-3xl h-14 bg-gradient-to-r from-primary to-accent hover:opacity-90 transition-opacity shadow-soft"
        >
          <Play className="w-4 h-4 mr-2" />
          Start New Session
        </Button>

        {/* Session History */}
        <div className="space-y-3">
          {sessions.map((session, index) => (
            <button
              key={session.id}
              onClick={() => router.push("/report")}
              className="w-full glass rounded-3xl p-5 shadow-soft hover:shadow-soft-lg transition-all hover:scale-[1.02]"
            >
              <div className="flex items-center justify-between mb-3">
                <div className="text-left">
                  <h3 className="font-semibold">{session.type}</h3>
                  <p className="text-xs text-muted-foreground">{session.date}</p>
                </div>
                <div className="text-right">
                  <div className="text-2xl font-bold text-primary">{session.score}%</div>
                </div>
              </div>
              <div className="flex items-center gap-4 text-xs text-muted-foreground">
                <div className="flex items-center gap-1">
                  <Clock className="w-3 h-3" />
                  <span>{session.duration}</span>
                </div>
                <div className="flex items-center gap-1">
                  <TrendingUp className="w-3 h-3 text-success" />
                  <span>View Report</span>
                </div>
              </div>
            </button>
          ))}
        </div>
      </main>

      <BottomNavigation />
    </div>
  )
}
