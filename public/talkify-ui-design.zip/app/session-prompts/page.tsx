"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { ChevronLeft, User, GraduationCap, Briefcase } from "lucide-react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"
import { motion } from "framer-motion"

const prompts = [
  {
    id: "personal-intro",
    title: "Personal Intro",
    description: "Practice introducing yourself confidently",
    icon: User,
    color: "bg-pastel-pink",
    textColor: "text-accent",
  },
  {
    id: "thesis-defense",
    title: "Thesis Defense",
    description: "Prepare for academic presentations",
    icon: GraduationCap,
    color: "bg-pastel-blue",
    textColor: "text-secondary",
  },
  {
    id: "job-interview",
    title: "Job Interview",
    description: "Master professional conversations",
    icon: Briefcase,
    color: "bg-pastel-purple",
    textColor: "text-primary",
  },
]

export default function SessionPromptsPage() {
  const router = useRouter()
  const [selectedPrompt, setSelectedPrompt] = useState<string | null>(null)

  const handlePromptSelect = (promptId: string) => {
    setSelectedPrompt(promptId)
  }

  const handleNext = () => {
    if (selectedPrompt) {
      router.push(`/preparation?prompt=${selectedPrompt}`)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-pastel-blue/30 via-background to-pastel-pink/30">
      {/* Header */}
      <header className="px-6 pt-12 pb-6 flex items-center gap-4">
        <button
          onClick={() => router.back()}
          className="w-10 h-10 rounded-full glass flex items-center justify-center shadow-soft hover:scale-105 transition-transform"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>
        <div className="flex-1">
          <h1 className="text-xl font-bold">Choose Your Session</h1>
          <p className="text-sm text-muted-foreground">Select a practice scenario</p>
        </div>
      </header>

      {/* Main Content */}
      <main className="px-6 pb-32">
        <div className="mb-6">
          <h2 className="text-2xl font-bold mb-2 text-balance">What would you like to practice today?</h2>
          <p className="text-sm text-muted-foreground leading-relaxed">
            Choose a scenario to begin your AI-powered speaking session
          </p>
        </div>

        {/* The Row - Three Cards */}
        <div className="space-y-4">
          {prompts.map((prompt, index) => {
            const Icon = prompt.icon
            const isSelected = selectedPrompt === prompt.id

            return (
              <motion.button
                key={prompt.id}
                onClick={() => handlePromptSelect(prompt.id)}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className={cn(
                  "w-full rounded-3xl p-6 shadow-soft-lg transition-all duration-300 relative overflow-hidden",
                  prompt.color,
                  isSelected && "scale-[1.02] shadow-soft-lg ring-2 ring-primary ring-offset-4 ring-offset-background",
                )}
              >
                <div className="flex items-center gap-6">
                  <div
                    className={cn(
                      "w-16 h-16 rounded-2xl flex items-center justify-center bg-white/80 backdrop-blur-sm shadow-soft",
                    )}
                  >
                    <Icon className={cn("w-8 h-8", prompt.textColor)} strokeWidth={2} />
                  </div>
                  <div className="flex-1 text-left">
                    <h3 className="text-xl font-bold mb-1 text-foreground">{prompt.title}</h3>
                    <p className="text-sm text-muted-foreground leading-relaxed">{prompt.description}</p>
                  </div>
                  <div
                    className={cn(
                      "w-6 h-6 rounded-full border-2 transition-all duration-300",
                      isSelected
                        ? "bg-primary border-primary scale-110"
                        : "bg-white/50 border-white/80 backdrop-blur-sm",
                    )}
                  >
                    {isSelected && (
                      <motion.div
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        className="w-full h-full flex items-center justify-center"
                      >
                        <div className="w-2 h-2 rounded-full bg-white" />
                      </motion.div>
                    )}
                  </div>
                </div>

                {/* Decorative gradient overlay */}
                {isSelected && (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="absolute inset-0 bg-gradient-to-r from-primary/10 to-accent/10 pointer-events-none rounded-3xl"
                  />
                )}
              </motion.button>
            )
          })}
        </div>

        {/* Info Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="mt-8 glass rounded-3xl p-6 shadow-soft"
        >
          <h3 className="font-semibold mb-2">How it works</h3>
          <ul className="space-y-2 text-sm text-muted-foreground">
            <li className="flex items-start gap-2">
              <div className="w-5 h-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                <span className="text-xs font-bold text-primary">1</span>
              </div>
              <span>Select your practice scenario</span>
            </li>
            <li className="flex items-start gap-2">
              <div className="w-5 h-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                <span className="text-xs font-bold text-primary">2</span>
              </div>
              <span>Review the talking points</span>
            </li>
            <li className="flex items-start gap-2">
              <div className="w-5 h-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                <span className="text-xs font-bold text-primary">3</span>
              </div>
              <span>Practice with AI feedback</span>
            </li>
          </ul>
        </motion.div>
      </main>

      {/* Fixed Bottom Button */}
      <div className="fixed bottom-0 left-0 right-0 p-6 glass border-t border-border/50">
        <Button
          onClick={handleNext}
          disabled={!selectedPrompt}
          className="w-full rounded-3xl h-14 bg-gradient-to-r from-primary to-accent hover:opacity-90 transition-opacity shadow-soft disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {selectedPrompt ? "Continue to Preparation" : "Select a Session Type"}
        </Button>
      </div>
    </div>
  )
}
