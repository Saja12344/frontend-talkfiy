"use client"

import { useRouter } from "next/navigation"
import { BottomNavigation } from "@/components/bottom-navigation"
import { Users, Lock, Crown } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useEffect, useState } from "react"

export default function CommunityPage() {
  const router = useRouter()
  const [isMinor, setIsMinor] = useState(false)

  useEffect(() => {
    const profileData = localStorage.getItem("talkifyProfile")
    if (profileData) {
      const profile = JSON.parse(profileData)
      setIsMinor(profile.isMinor)
    }
  }, [])

  return (
    <div className="min-h-screen bg-gradient-to-br from-pastel-pink/30 via-background to-pastel-green/30 pb-20">
      {/* Header */}
      <header className="px-6 pt-12 pb-6">
        <h1 className="text-2xl font-bold mb-2">Community</h1>
        <p className="text-sm text-muted-foreground">Connect with other learners</p>
      </header>

      {/* Main Content */}
      <main className="px-6">
        {isMinor ? (
          <div className="glass rounded-3xl p-8 shadow-soft-lg text-center space-y-4">
            <div className="w-16 h-16 mx-auto rounded-full bg-muted/30 flex items-center justify-center">
              <Lock className="w-8 h-8 text-muted-foreground" />
            </div>
            <h2 className="text-xl font-bold">Restricted for Minors</h2>
            <p className="text-muted-foreground leading-relaxed">
              Group sessions and live coach features are restricted for users under 18 years old for safety reasons.
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {/* Group Sessions Card */}
            <div className="glass rounded-3xl p-6 shadow-soft-lg">
              <div className="flex items-start gap-4 mb-4">
                <div className="w-12 h-12 rounded-2xl bg-pastel-blue flex items-center justify-center">
                  <Users className="w-6 h-6 text-secondary" />
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold mb-1">Group Sessions</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    Practice with peers in collaborative sessions
                  </p>
                </div>
                <div className="px-2 py-1 rounded-full bg-primary/20">
                  <Crown className="w-4 h-4 text-primary" />
                </div>
              </div>
              <Button onClick={() => router.push("/premium")} variant="outline" className="w-full rounded-3xl">
                Upgrade to Access
              </Button>
            </div>

            {/* Live Coach Card */}
            <div className="glass rounded-3xl p-6 shadow-soft-lg">
              <div className="flex items-start gap-4 mb-4">
                <div className="w-12 h-12 rounded-2xl bg-pastel-purple flex items-center justify-center">
                  <Users className="w-6 h-6 text-primary" />
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold mb-1">Live Coach</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    Get real-time feedback from professional coaches
                  </p>
                </div>
                <div className="px-2 py-1 rounded-full bg-primary/20">
                  <Crown className="w-4 h-4 text-primary" />
                </div>
              </div>
              <Button onClick={() => router.push("/premium")} variant="outline" className="w-full rounded-3xl">
                Upgrade to Access
              </Button>
            </div>
          </div>
        )}
      </main>

      <BottomNavigation />
    </div>
  )
}
