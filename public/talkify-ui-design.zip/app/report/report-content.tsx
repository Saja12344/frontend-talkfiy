"use client"

import { useRouter, useSearchParams } from "next/navigation"
import { X, TrendingUp, Volume2, Zap, Eye, AlertCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { motion } from "framer-motion"
import { cn } from "@/lib/utils"

const timelineData = [
  { time: 0, type: "filler", label: "Um..." },
  { time: 45, type: "pacing", label: "Fast" },
  { time: 90, type: "tone", label: "Confident" },
  { time: 135, type: "filler", label: "Like..." },
  { time: 180, type: "tone", label: "Engaged" },
  { time: 225, type: "pacing", label: "Good" },
  { time: 270, type: "filler", label: "Uh..." },
]

export function ReportContent() {
  const router = useRouter()
  const searchParams = useSearchParams()

  return (
    <div className="min-h-screen bg-gradient-to-br from-pastel-blue/30 via-background to-pastel-purple/30 pb-20">
      {/* Header */}
      <header className="px-6 pt-12 pb-6 flex items-center justify-between">
        <div className="flex-1">
          <h1 className="text-2xl font-bold">Session Report</h1>
          <p className="text-sm text-muted-foreground">Your performance analysis</p>
        </div>
        <button
          onClick={() => router.push("/")}
          className="w-10 h-10 rounded-full glass flex items-center justify-center shadow-soft hover:scale-105 transition-transform"
        >
          <X className="w-5 h-5" />
        </button>
      </header>

      {/* Main Content */}
      <main className="px-6 space-y-6">
        {/* Overall Score */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass rounded-3xl p-8 shadow-soft-lg text-center"
        >
          <div className="mb-4">
            <div className="text-6xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
              85%
            </div>
            <div className="text-sm text-muted-foreground mt-2">Overall Performance</div>
          </div>
          <div className="flex items-center justify-center gap-2 text-success">
            <TrendingUp className="w-4 h-4" />
            <span className="text-sm font-medium">+12% from last session</span>
          </div>
        </motion.div>

        {/* Timeline Visualization */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="glass rounded-3xl p-6 shadow-soft-lg"
        >
          <h3 className="font-semibold mb-4">Session Timeline (5:00)</h3>

          <div className="relative">
            <div className="flex justify-between text-xs text-muted-foreground mb-2">
              <span>0:00</span>
              <span>1:15</span>
              <span>2:30</span>
              <span>3:45</span>
              <span>5:00</span>
            </div>

            <div className="relative h-12 bg-muted/30 rounded-full overflow-hidden">
              {timelineData.map((item, index) => {
                const position = (item.time / 300) * 100
                const colors = {
                  filler: "bg-destructive",
                  pacing: "bg-warning",
                  tone: "bg-success",
                }

                return (
                  <motion.div
                    key={index}
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ delay: 0.2 + index * 0.1 }}
                    className="absolute top-1/2 -translate-y-1/2 group"
                    style={{ left: `${position}%` }}
                  >
                    <div className={cn("w-3 h-3 rounded-full", colors[item.type as keyof typeof colors])} />
                    <div className="absolute top-full mt-2 left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity bg-black/80 text-white text-xs px-2 py-1 rounded whitespace-nowrap pointer-events-none">
                      {item.label}
                    </div>
                  </motion.div>
                )
              })}
            </div>

            <div className="flex items-center justify-center gap-4 mt-4 text-xs">
              <div className="flex items-center gap-1.5">
                <div className="w-3 h-3 rounded-full bg-destructive" />
                <span className="text-muted-foreground">Fillers</span>
              </div>
              <div className="flex items-center gap-1.5">
                <div className="w-3 h-3 rounded-full bg-warning" />
                <span className="text-muted-foreground">Pacing</span>
              </div>
              <div className="flex items-center gap-1.5">
                <div className="w-3 h-3 rounded-full bg-success" />
                <span className="text-muted-foreground">Tone</span>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Radial Progress Charts */}
        <div className="grid grid-cols-2 gap-4">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2 }}
            className="bg-pastel-green rounded-3xl p-6 shadow-soft"
          >
            <div className="relative w-24 h-24 mx-auto mb-3">
              <svg className="w-full h-full -rotate-90">
                <circle
                  cx="48"
                  cy="48"
                  r="40"
                  stroke="currentColor"
                  strokeWidth="8"
                  fill="none"
                  className="text-white/30"
                />
                <circle
                  cx="48"
                  cy="48"
                  r="40"
                  stroke="currentColor"
                  strokeWidth="8"
                  fill="none"
                  strokeDasharray={`${2 * Math.PI * 40}`}
                  strokeDashoffset={`${2 * Math.PI * 40 * (1 - 0.82)}`}
                  className="text-success transition-all duration-1000"
                  strokeLinecap="round"
                />
              </svg>
              <div className="absolute inset-0 flex items-center justify-center">
                <span className="text-2xl font-bold text-success">82%</span>
              </div>
            </div>
            <div className="text-center">
              <div className="font-semibold text-sm">Clarity Score</div>
              <div className="text-xs text-muted-foreground">Excellent</div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.3 }}
            className="bg-pastel-purple rounded-3xl p-6 shadow-soft"
          >
            <div className="relative w-24 h-24 mx-auto mb-3">
              <svg className="w-full h-full -rotate-90">
                <circle
                  cx="48"
                  cy="48"
                  r="40"
                  stroke="currentColor"
                  strokeWidth="8"
                  fill="none"
                  className="text-white/30"
                />
                <circle
                  cx="48"
                  cy="48"
                  r="40"
                  stroke="currentColor"
                  strokeWidth="8"
                  fill="none"
                  strokeDasharray={`${2 * Math.PI * 40}`}
                  strokeDashoffset={`${2 * Math.PI * 40 * (1 - 0.75)}`}
                  className="text-primary transition-all duration-1000"
                  strokeLinecap="round"
                />
              </svg>
              <div className="absolute inset-0 flex items-center justify-center">
                <span className="text-2xl font-bold text-primary">75%</span>
              </div>
            </div>
            <div className="text-center">
              <div className="font-semibold text-sm">Confidence</div>
              <div className="text-xs text-muted-foreground">Very Good</div>
            </div>
          </motion.div>
        </div>

        {/* Bar Graphs */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="glass rounded-3xl p-6 shadow-soft-lg space-y-6"
        >
          <div>
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Volume2 className="w-4 h-4 text-secondary" />
                <span className="font-semibold text-sm">Speech Volume</span>
              </div>
              <span className="text-sm text-muted-foreground">78 dB avg</span>
            </div>
            <div className="space-y-2">
              {[65, 82, 78, 85, 72].map((value, index) => (
                <div key={index} className="flex items-center gap-3">
                  <span className="text-xs text-muted-foreground w-8">{index + 1}m</span>
                  <div className="flex-1 h-3 bg-muted/30 rounded-full overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${value}%` }}
                      transition={{ delay: 0.5 + index * 0.1, duration: 0.5 }}
                      className="h-full bg-gradient-to-r from-secondary to-pastel-blue rounded-full"
                    />
                  </div>
                  <span className="text-xs font-medium w-8">{value}</span>
                </div>
              ))}
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Zap className="w-4 h-4 text-warning" />
                <span className="font-semibold text-sm">Words Per Minute</span>
              </div>
              <span className="text-sm text-muted-foreground">142 avg</span>
            </div>
            <div className="space-y-2">
              {[135, 158, 142, 138, 145].map((value, index) => (
                <div key={index} className="flex items-center gap-3">
                  <span className="text-xs text-muted-foreground w-8">{index + 1}m</span>
                  <div className="flex-1 h-3 bg-muted/30 rounded-full overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${(value / 200) * 100}%` }}
                      transition={{ delay: 1 + index * 0.1, duration: 0.5 }}
                      className="h-full bg-gradient-to-r from-warning to-pastel-pink rounded-full"
                    />
                  </div>
                  <span className="text-xs font-medium w-8">{value}</span>
                </div>
              ))}
            </div>
          </div>
        </motion.div>

        {/* Eye Contact Heatmap */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="glass rounded-3xl p-6 shadow-soft-lg"
        >
          <div className="flex items-center gap-2 mb-4">
            <Eye className="w-4 h-4 text-accent" />
            <h3 className="font-semibold">Eye Contact Quality</h3>
          </div>

          <div className="grid grid-cols-10 gap-1">
            {Array.from({ length: 50 }).map((_, index) => {
              const intensity = Math.random()
              const colors = intensity > 0.7 ? "bg-success" : intensity > 0.4 ? "bg-warning" : "bg-destructive/40"

              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, scale: 0 }}
                  animate={{ opacity: 0.3 + intensity * 0.7, scale: 1 }}
                  transition={{ delay: 0.6 + index * 0.01 }}
                  className={cn("aspect-square rounded-sm", colors)}
                />
              )
            })}
          </div>

          <div className="flex items-center justify-between mt-4 text-xs text-muted-foreground">
            <span>Poor</span>
            <span>Good</span>
            <span>Excellent</span>
          </div>
        </motion.div>

        {/* Key Insights */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="glass rounded-3xl p-6 shadow-soft-lg space-y-4"
        >
          <h3 className="font-semibold flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-primary" />
            Key Insights
          </h3>

          <div className="space-y-3">
            <div className="flex gap-3 p-4 rounded-2xl bg-success/10">
              <div className="w-8 h-8 rounded-full bg-success/20 flex items-center justify-center flex-shrink-0">
                <TrendingUp className="w-4 h-4 text-success" />
              </div>
              <div>
                <div className="font-medium text-sm">Strong Clarity</div>
                <div className="text-xs text-muted-foreground leading-relaxed">
                  Your pronunciation was clear and easy to follow
                </div>
              </div>
            </div>

            <div className="flex gap-3 p-4 rounded-2xl bg-warning/10">
              <div className="w-8 h-8 rounded-full bg-warning/20 flex items-center justify-center flex-shrink-0">
                <Volume2 className="w-4 h-4 text-warning" />
              </div>
              <div>
                <div className="font-medium text-sm">Reduce Filler Words</div>
                <div className="text-xs text-muted-foreground leading-relaxed">
                  Try to minimize "um" and "like" - detected 7 instances
                </div>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Action Buttons */}
        <div className="space-y-3 pb-8">
          <Button
            onClick={() => router.push("/session-prompts")}
            className="w-full rounded-3xl h-14 bg-gradient-to-r from-primary to-accent hover:opacity-90 transition-opacity shadow-soft"
          >
            Practice Again
          </Button>
          <Button onClick={() => router.push("/")} variant="outline" className="w-full rounded-3xl h-14">
            Back to Home
          </Button>
        </div>
      </main>
    </div>
  )
}
