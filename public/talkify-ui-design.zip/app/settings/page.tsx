"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Shield, Cloud, Trash2, Crown, ChevronRight, User, Bell, Lock } from "lucide-react"
import { Button } from "@/components/ui/button"
import { BottomNavigation } from "@/components/bottom-navigation"
import { motion, AnimatePresence } from "framer-motion"
import { cn } from "@/lib/utils"

export default function SettingsPage() {
  const router = useRouter()
  const [showDeleteModal, setShowDeleteModal] = useState(false)
  const [cloudStorageEnabled, setCloudStorageEnabled] = useState(true)

  const handleDeleteAllRecordings = () => {
    setShowDeleteModal(false)
    // In a real app, this would delete all recordings
    alert("All recordings deleted successfully")
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-pastel-purple/30 via-background to-pastel-green/30 pb-20">
      {/* Header */}
      <header className="px-6 pt-12 pb-6">
        <div className="flex items-center gap-4 mb-6">
          <h1 className="text-2xl font-bold">Settings</h1>
        </div>
      </header>

      {/* Main Content */}
      <main className="px-6 space-y-6">
        {/* Profile Section */}
        <div className="glass rounded-3xl p-6 shadow-soft-lg">
          <h3 className="font-semibold mb-4 flex items-center gap-2">
            <User className="w-4 h-4" />
            Profile
          </h3>
          <div className="space-y-3">
            <button className="w-full flex items-center justify-between p-4 rounded-2xl hover:bg-muted/20 transition-colors">
              <div>
                <div className="font-medium text-sm">Edit Profile</div>
                <div className="text-xs text-muted-foreground">Update your information</div>
              </div>
              <ChevronRight className="w-4 h-4 text-muted-foreground" />
            </button>
            <button
              onClick={() => router.push("/premium")}
              className="w-full flex items-center justify-between p-4 rounded-2xl bg-gradient-to-r from-primary/10 to-accent/10 hover:from-primary/20 hover:to-accent/20 transition-colors"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center">
                  <Crown className="w-5 h-5 text-white" />
                </div>
                <div>
                  <div className="font-semibold text-sm">Upgrade to Pro</div>
                  <div className="text-xs text-muted-foreground">Unlock all features</div>
                </div>
              </div>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Privacy Vault */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass rounded-3xl p-6 shadow-soft-lg"
        >
          <h3 className="font-semibold mb-4 flex items-center gap-2">
            <Lock className="w-4 h-4" />
            Privacy Vault
          </h3>

          <div className="space-y-4">
            {/* Cloud Storage Toggle */}
            <div className="flex items-center justify-between p-4 rounded-2xl bg-pastel-blue/30">
              <div className="flex items-center gap-3">
                <Cloud className="w-5 h-5 text-secondary" />
                <div>
                  <div className="font-medium text-sm">Cloud Storage</div>
                  <div className="text-xs text-muted-foreground">Sync recordings across devices</div>
                </div>
              </div>
              <button
                onClick={() => setCloudStorageEnabled(!cloudStorageEnabled)}
                className={cn(
                  "w-12 h-7 rounded-full transition-colors relative",
                  cloudStorageEnabled ? "bg-primary" : "bg-muted",
                )}
              >
                <motion.div
                  animate={{ x: cloudStorageEnabled ? 20 : 2 }}
                  className="absolute top-1 w-5 h-5 bg-white rounded-full shadow-soft"
                />
              </button>
            </div>

            {/* Delete All Recordings */}
            <button
              onClick={() => setShowDeleteModal(true)}
              className="w-full flex items-center gap-3 p-4 rounded-2xl bg-destructive/10 hover:bg-destructive/20 transition-colors"
            >
              <Trash2 className="w-5 h-5 text-destructive" />
              <div className="flex-1 text-left">
                <div className="font-medium text-sm text-destructive">Delete All My Recordings</div>
                <div className="text-xs text-muted-foreground">This action cannot be undone</div>
              </div>
            </button>

            {/* Privacy Shield */}
            <div className="p-4 rounded-2xl bg-success/10">
              <div className="flex items-start gap-3">
                <Shield className="w-5 h-5 text-success flex-shrink-0 mt-0.5" />
                <div className="text-xs text-muted-foreground leading-relaxed">
                  <p className="font-semibold text-foreground mb-1">Your privacy is protected</p>
                  <p>All recordings are encrypted end-to-end. You have full control over your data.</p>
                </div>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Notifications */}
        <div className="glass rounded-3xl p-6 shadow-soft-lg">
          <h3 className="font-semibold mb-4 flex items-center gap-2">
            <Bell className="w-4 h-4" />
            Notifications
          </h3>
          <div className="space-y-3">
            <button className="w-full flex items-center justify-between p-4 rounded-2xl hover:bg-muted/20 transition-colors">
              <div>
                <div className="font-medium text-sm">Push Notifications</div>
                <div className="text-xs text-muted-foreground">Session reminders</div>
              </div>
              <ChevronRight className="w-4 h-4 text-muted-foreground" />
            </button>
          </div>
        </div>

        {/* App Info */}
        <div className="text-center text-xs text-muted-foreground pb-8">
          <p>Talkify v1.0.0</p>
          <p className="mt-1">Made with care for university students</p>
        </div>
      </main>

      {/* Delete Confirmation Modal */}
      <AnimatePresence>
        {showDeleteModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-6"
          >
            <motion.div
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              className="glass rounded-3xl p-8 max-w-md w-full shadow-soft-lg"
            >
              <div className="text-center space-y-4">
                <div className="w-16 h-16 mx-auto rounded-full bg-destructive/20 flex items-center justify-center">
                  <Trash2 className="w-8 h-8 text-destructive" />
                </div>
                <h2 className="text-2xl font-bold">Delete All Recordings?</h2>
                <p className="text-muted-foreground leading-relaxed">
                  This will permanently delete all your session recordings from our servers. This action cannot be
                  undone.
                </p>
                <div className="pt-4 space-y-3">
                  <Button
                    onClick={handleDeleteAllRecordings}
                    className="w-full rounded-3xl bg-destructive hover:opacity-90"
                  >
                    Yes, Delete Everything
                  </Button>
                  <Button onClick={() => setShowDeleteModal(false)} variant="outline" className="w-full rounded-3xl">
                    Cancel
                  </Button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <BottomNavigation />
    </div>
  )
}
