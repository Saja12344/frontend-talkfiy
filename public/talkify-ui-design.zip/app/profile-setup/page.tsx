"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { ChevronDown, ChevronLeft, Check, AlertCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { cn } from "@/lib/utils"

const SAUDI_UNIVERSITIES = [
  "King Saud University (KSU)",
  "King Fahd University of Petroleum & Minerals (KFUPM)",
  "King Abdulaziz University (KAU)",
  "Princess Nourah bint Abdulrahman University (PNU)",
  "Imam Abdulrahman Bin Faisal University (IAU)",
  "King Khalid University (KKU)",
  "Umm Al-Qura University",
  "King Faisal University (KFU)",
  "Taibah University",
  "Qassim University",
  "Jazan University",
  "Najran University",
  "Northern Border University",
  "University of Tabuk",
  "University of Hafr Al Batin",
]

export default function ProfileSetupPage() {
  const router = useRouter()
  const [step, setStep] = useState<"name" | "university" | "age">("name")
  const [name, setName] = useState("")
  const [university, setUniversity] = useState("")
  const [age, setAge] = useState("")
  const [showUniversityDropdown, setShowUniversityDropdown] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")

  const filteredUniversities = SAUDI_UNIVERSITIES.filter((uni) => uni.toLowerCase().includes(searchQuery.toLowerCase()))

  const handleNext = () => {
    if (step === "name" && name) {
      setStep("university")
    } else if (step === "university" && university) {
      setStep("age")
    } else if (step === "age" && age) {
      // Store profile data and navigate
      const ageNum = Number.parseInt(age)
      localStorage.setItem("talkifyProfile", JSON.stringify({ name, university, age: ageNum, isMinor: ageNum < 18 }))
      router.push("/session-prompts")
    }
  }

  const handleBack = () => {
    if (step === "university") setStep("name")
    else if (step === "age") setStep("university")
    else router.push("/")
  }

  const isMinor = age && Number.parseInt(age) < 18

  return (
    <div className="min-h-screen bg-gradient-to-br from-pastel-purple/30 via-background to-pastel-green/30">
      {/* Header */}
      <header className="px-6 pt-12 pb-6 flex items-center gap-4">
        <button
          onClick={handleBack}
          className="w-10 h-10 rounded-full glass flex items-center justify-center shadow-soft hover:scale-105 transition-transform"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>
        <div className="flex-1">
          <h1 className="text-xl font-bold">Profile Setup</h1>
          <p className="text-sm text-muted-foreground">
            Step {step === "name" ? "1" : step === "university" ? "2" : "3"} of 3
          </p>
        </div>
      </header>

      {/* Progress Bar */}
      <div className="px-6 mb-8">
        <div className="h-2 bg-muted rounded-full overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-primary to-accent transition-all duration-500"
            style={{
              width: step === "name" ? "33%" : step === "university" ? "66%" : "100%",
            }}
          />
        </div>
      </div>

      {/* Content */}
      <main className="px-6">
        {step === "name" && (
          <div className="glass rounded-3xl p-8 shadow-soft-lg space-y-6">
            <div>
              <h2 className="text-2xl font-bold mb-2">What's your name?</h2>
              <p className="text-sm text-muted-foreground leading-relaxed">Let's personalize your Talkify experience</p>
            </div>
            <div className="space-y-2">
              <Label htmlFor="name">Full Name</Label>
              <Input
                id="name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Enter your full name"
                className="h-14 rounded-2xl text-base"
              />
            </div>
          </div>
        )}

        {step === "university" && (
          <div className="glass rounded-3xl p-8 shadow-soft-lg space-y-6">
            <div>
              <h2 className="text-2xl font-bold mb-2">Your University</h2>
              <p className="text-sm text-muted-foreground leading-relaxed">Select your institution</p>
            </div>
            <div className="space-y-2">
              <Label htmlFor="university">University</Label>
              <div className="relative">
                <button
                  onClick={() => setShowUniversityDropdown(!showUniversityDropdown)}
                  className={cn(
                    "w-full h-14 rounded-2xl glass border border-border px-4 flex items-center justify-between text-left",
                    !university && "text-muted-foreground",
                  )}
                >
                  <span>{university || "Select your university"}</span>
                  <ChevronDown className={cn("w-5 h-5 transition-transform", showUniversityDropdown && "rotate-180")} />
                </button>

                {showUniversityDropdown && (
                  <div className="absolute top-full left-0 right-0 mt-2 glass rounded-2xl shadow-soft-lg overflow-hidden z-10 max-h-96">
                    <div className="p-3 border-b border-border">
                      <Input
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        placeholder="Search universities..."
                        className="h-10 rounded-xl"
                      />
                    </div>
                    <div className="max-h-64 overflow-y-auto">
                      {filteredUniversities.map((uni) => (
                        <button
                          key={uni}
                          onClick={() => {
                            setUniversity(uni)
                            setShowUniversityDropdown(false)
                            setSearchQuery("")
                          }}
                          className="w-full px-4 py-3 text-left hover:bg-muted/50 transition-colors flex items-center justify-between"
                        >
                          <span>{uni}</span>
                          {university === uni && <Check className="w-4 h-4 text-primary" />}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {step === "age" && (
          <div className="space-y-6">
            <div className="glass rounded-3xl p-8 shadow-soft-lg space-y-6">
              <div>
                <h2 className="text-2xl font-bold mb-2">Age Verification</h2>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  We need to verify your age for safety features
                </p>
              </div>
              <div className="space-y-2">
                <Label htmlFor="age">Your Age</Label>
                <Input
                  id="age"
                  type="number"
                  value={age}
                  onChange={(e) => setAge(e.target.value)}
                  placeholder="Enter your age"
                  className="h-14 rounded-2xl text-base"
                  min="13"
                  max="99"
                />
              </div>
            </div>

            {isMinor && (
              <div className="bg-warning/20 border border-warning/30 rounded-3xl p-6 flex gap-4">
                <AlertCircle className="w-6 h-6 text-warning flex-shrink-0 mt-0.5" />
                <div className="space-y-2">
                  <h3 className="font-semibold">Minor Account Restrictions</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    Some features will be restricted for users under 18:
                  </p>
                  <ul className="text-sm space-y-1 text-muted-foreground">
                    <li>• Group Sessions (disabled)</li>
                    <li>• Live Coach (disabled)</li>
                  </ul>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Next Button */}
        <Button
          onClick={handleNext}
          disabled={(step === "name" && !name) || (step === "university" && !university) || (step === "age" && !age)}
          className="w-full mt-8 rounded-3xl h-14 bg-gradient-to-r from-primary to-accent hover:opacity-90 transition-opacity shadow-soft disabled:opacity-50"
        >
          {step === "age" ? "Complete Setup" : "Continue"}
        </Button>
      </main>
    </div>
  )
}
