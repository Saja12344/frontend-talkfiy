import { Suspense } from "react"
import { PreparationContent } from "./preparation-content"

export default function PreparationPage() {
  return (
    <Suspense
      fallback={
        <div className="min-h-screen bg-gradient-to-br from-pastel-green/30 via-background to-pastel-blue/30 flex items-center justify-center">
          <div className="text-center">
            <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4" />
            <p className="text-muted-foreground">Loading...</p>
          </div>
        </div>
      }
    >
      <PreparationContent />
    </Suspense>
  )
}
