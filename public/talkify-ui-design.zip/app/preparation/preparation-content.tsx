"use client"

import { useState, useEffect } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { ChevronLeft, CheckCircle2, Sparkles } from "lucide-react"
import { Button } from "@/components/ui/button"
import { motion, AnimatePresence } from "framer-motion"

const talkingPoints = {
  "personal-intro": [
    "Share your hobbies and interests",
    "Mention your academic background",
    "Highlight your career goals",
  ],
  "thesis-defense": [
    "Explain your research methodology",
    "Present key findings clearly",
    "Prepare for critical questions",
  ],
  "job-interview": [
    "Discuss your relevant experience",
    "Explain why you're interested in the role",
    "Showcase your unique strengths",
  ],
}

export function PreparationContent() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const prompt = (searchParams?.get("prompt") || "personal-intro") as keyof typeof talkingPoints
  const [countdown, setCountdown] = useState(5)
  const [isCountingDown, setIsCountingDown] = useState(false)

  useEffect(() => {
    if (isCountingDown && countdown > 0) {
      const timer = setTimeout(() => setCountdown(countdown - 1), 1000)
      return () => clearTimeout(timer)
    } else if (isCountingDown && countdown === 0) {
      router.push(`/ai-session?prompt=${prompt}`)
    }
  }, [countdown, isCountingDown, router, prompt])

  const points = talkingPoints[prompt] || talkingPoints["personal-intro"]

  return (
    <div className="min-h-screen bg-gradient-to-br from-pastel-green/30 via-background to-pastel-blue/30">
      {/* Header */}
      <header className="px-6 pt-12 pb-6 flex items-center gap-4">
        <button
          onClick={() => router.back()}
          className="w-10 h-10 rounded-full glass flex items-center justify-center shadow-soft hover:scale-105 transition-transform"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>
        <div className="flex-1">
          <h1 className="text-xl font-bold">Preparation</h1>
          <p className="text-sm text-muted-foreground">Focus Mode</p>
        </div>
      </header>

      {/* Main Content */}
      <main className="px-6 pb-32">
        <AnimatePresence mode="wait">
          {!isCountingDown ? (
            <motion.div
              key="preparation"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="space-y-6"
            >
              {/* Focus Mode Card */}
              <div className="glass rounded-3xl p-8 shadow-soft-lg">
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-12 h-12 bg-gradient-to-br from-primary to-accent rounded-2xl flex items-center justify-center shadow-soft">
                    <Sparkles className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h2 className="text-xl font-bold">Get Ready!</h2>
                    <p className="text-sm text-muted-foreground">Review these talking points</p>
                  </div>
                </div>

                {/* Talking Points */}
                <div className="space-y-4">
                  {points.map((point, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.1 }}
                      className="flex items-start gap-3 p-4 rounded-2xl bg-pastel-green/50"
                    >
                      <CheckCircle2 className="w-5 h-5 text-success flex-shrink-0 mt-0.5" />
                      <p className="text-sm leading-relaxed">{point}</p>
                    </motion.div>
                  ))}
                </div>
              </div>

              {/* Tips Card */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 }}
                className="glass rounded-3xl p-6 shadow-soft"
              >
                <h3 className="font-semibold mb-3">Quick Tips</h3>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li className="flex items-start gap-2">
                    <span className="text-primary">•</span>
                    <span>Speak clearly and at a steady pace</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-primary">•</span>
                    <span>Maintain good posture and eye contact</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-primary">•</span>
                    <span>Take your time to organize your thoughts</span>
                  </li>
                </ul>
              </motion.div>

              {/* Start Button */}
              <Button
                onClick={() => setIsCountingDown(true)}
                className="w-full rounded-3xl h-14 bg-gradient-to-r from-primary to-accent hover:opacity-90 transition-opacity shadow-soft"
              >
                <Sparkles className="w-4 h-4 mr-2" />
                I'm Ready - Start Session
              </Button>
            </motion.div>
          ) : (
            <motion.div
              key="countdown"
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="flex items-center justify-center min-h-[60vh]"
            >
              <div className="text-center">
                <motion.div
                  key={countdown}
                  initial={{ scale: 0.5, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  exit={{ scale: 1.5, opacity: 0 }}
                  transition={{ duration: 0.5 }}
                  className="w-32 h-32 mx-auto mb-6 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center shadow-soft-lg"
                >
                  <span className="text-6xl font-bold text-white">{countdown}</span>
                </motion.div>
                <h2 className="text-2xl font-bold mb-2">Get Ready!</h2>
                <p className="text-muted-foreground">AI is activating...</p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>
    </div>
  )
}
